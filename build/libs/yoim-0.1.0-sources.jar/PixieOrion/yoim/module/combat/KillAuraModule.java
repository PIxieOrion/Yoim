package PixieOrion.yoim.module.combat;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.Category;
import PixieOrion.yoim.module.Module;
import PixieOrion.yoim.settings.impl.BooleanSetting;
import PixieOrion.yoim.settings.impl.CategorySetting;
import PixieOrion.yoim.settings.impl.ModeSetting;
import PixieOrion.yoim.settings.impl.NumberSetting;
import PixieOrion.yoim.util.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1560;
import net.minecraft.class_1590;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import PixieOrion.yoim.packets.PacketUtils;

public final class KillAuraModule extends Module {
    public final ModeSetting autoSwitch = setting(new ModeSetting("Switch", "Choose whether a sword is required or selected automatically.", "None", "None", "Normal", "Require"));
    public final ModeSetting hitDelay = setting(new ModeSetting("HitDelay", "The delay between attacks.", "Vanilla", "None", "Vanilla", "Custom"));
    public final NumberSetting speed = setting(new NumberSetting("Speed", "Custom attack rate.", "Speed", () -> hitDelay.getValue().equals("Custom"), 20.0f, 0.1f, 20.0f));
    public final ModeSetting rotate = setting(new ModeSetting("Rotate", "How rotations are applied to the target.", "Hold", "None", "Normal", "Hold", "Packet"));
    public final ModeSetting swing = setting(new ModeSetting("Swing", "How the hand swing is displayed or sent.", "Mainhand", "None", "Packet", "Mainhand", "Offhand", "Both"));
    public final NumberSetting range = setting(new NumberSetting("Range", "Maximum target distance.", 6.0, 0.0, 12.0));
    public final BooleanSetting raytrace = setting(new BooleanSetting("Raytrace", "Only target entities visible through blocks.", false));
    public final NumberSetting wallsRange = setting(new NumberSetting("WallsRange", "WallsRange", "Maximum target distance through walls.", () -> !raytrace.getValue(), 5.0, 0.0, 12.0));
    public final NumberSetting ticksExisted = setting(new NumberSetting("TicksExisted", "Minimum age of a target in ticks.", 50, 0, 240));

    public final CategorySetting entitiesCategory = setting(new CategorySetting("Entities", "Target selection settings."));
    public final BooleanSetting players = setting(new BooleanSetting("Players", "Players", "Target players.", () -> entitiesCategory.isOpen(), true));
    public final BooleanSetting animals = setting(new BooleanSetting("Animals", "Animals", "Target animals and aquatic creatures.", () -> entitiesCategory.isOpen(), false));
    public final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Hostiles", "Target hostile mobs.", () -> entitiesCategory.isOpen(), false));
    public final BooleanSetting passives = setting(new BooleanSetting("Passives", "Passives", "Allow normally passive hostile mobs.", () -> entitiesCategory.isOpen() && hostiles.getValue(), false));
    public final BooleanSetting ambient = setting(new BooleanSetting("Ambient", "Ambient", "Target ambient creatures.", () -> entitiesCategory.isOpen(), false));
    public final BooleanSetting invisibles = setting(new BooleanSetting("Invisibles", "Invisibles", "Target invisible entities.", () -> entitiesCategory.isOpen(), false));
    public final BooleanSetting boats = setting(new BooleanSetting("Boats", "Boats", "Target boats.", () -> entitiesCategory.isOpen(), false));
    public final BooleanSetting shulkerBullets = setting(new BooleanSetting("ShulkerBullets", "ShulkerBullets", "Target shulker bullets.", () -> entitiesCategory.isOpen(), true));

    private class_1297 target;
    private long lastAttackTime;
    private boolean attacking;
    private float silentYaw;
    private float silentPitch;
    private boolean silentRotationActive;

    public KillAuraModule() {
        super("KillAura", Category.COMBAT, "Automatically selects and attacks nearby entities.");
    }

    public class_1297 getTarget() {
        return target;
    }

    public void prepareTick() {
        class_310 client = Yoim.mc();
        silentRotationActive = false;
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            target = null;
            attacking = false;
            return;
        }

        target = findTarget(client);
        attacking = target != null;
        String rotationMode = rotate.getValue();
        if (target != null && (rotationMode.equals("Hold") || (rotationMode.equals("Normal") && attackReady(client)))) {
            calculateRotation(client, target);
            silentRotationActive = true;
        }
    }

    public void attackTick() {
        class_310 client = Yoim.mc();
        if (!isEnabled() || target == null || client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;
        if (target.method_31481() || !target.method_5805() || (target instanceof class_1309 living && living.method_6032() <= 0.0f)) {
            target = null;
            attacking = false;
            return;
        }

        String switchMode = autoSwitch.getValue();
        int swordSlot = -1;
        if (switchMode.equals("Require") && !InventoryUtils.isSword(client.field_1724.method_6047().method_7909())) return;
        if (switchMode.equals("Normal")) {
            swordSlot = InventoryUtils.findBestSword(client);
            if (swordSlot == -1) return;
        }

        long now = System.nanoTime();
        String delayMode = hitDelay.getValue();
        if (delayMode.equals("Vanilla") && client.field_1724.method_7261(0.5f) < 1.0f) return;
        if (delayMode.equals("Custom")) {
            long delayNanos = (long) ((1000.0 - speed.getValue().doubleValue() * 50.0) * 1_000_000.0);
            if (delayNanos > 0 && now - lastAttackTime < delayNanos) return;
        }

        if (rotate.getValue().equals("Packet")) rotateAndSendPacket(client, target);

        if (switchMode.equals("Normal") && swordSlot != client.field_1724.method_31548().method_67532()) {
            client.field_1724.method_31548().method_61496(swordSlot);
            PacketUtils.send(new net.minecraft.class_2868(swordSlot));
        }

        client.field_1761.method_2918(client.field_1724, target);
        switch (swing.getValue()) {
            case "Packet" -> {
                PacketUtils.send(new net.minecraft.class_2879(class_1268.field_5808));
            }
            case "Mainhand" -> client.field_1724.method_6104(class_1268.field_5808);
            case "Offhand" -> client.field_1724.method_6104(class_1268.field_5810);
            case "Both" -> {
                client.field_1724.method_6104(class_1268.field_5808);
                client.field_1724.method_6104(class_1268.field_5810);
            }
        }
        lastAttackTime = now;
    }

    public boolean hasVisualRotation() {
        return isEnabled() && silentRotationActive && target != null
                && (rotate.getValue().equals("Hold") || rotate.getValue().equals("Normal"));
    }

    public float getSilentYaw() { return silentYaw; }
    public float getSilentPitch() { return silentPitch; }

    private void calculateRotation(class_310 client, class_1297 entity) {
        class_243 difference = entity.method_5829().method_1005().method_1020(client.field_1724.method_33571());
        double horizontal = Math.sqrt(difference.field_1352 * difference.field_1352 + difference.field_1350 * difference.field_1350);
        silentYaw = class_3532.method_15393((float) (Math.toDegrees(Math.atan2(difference.field_1350, difference.field_1352)) - 90.0));
        silentPitch = class_3532.method_15393((float) -Math.toDegrees(Math.atan2(difference.field_1351, horizontal)));
    }

    private void rotateAndSendPacket(class_310 client, class_1297 entity) {
        calculateRotation(client, entity);
        if (client.method_1562() != null) {
            client.method_1562().method_52787(new class_2828.class_2831(silentYaw, silentPitch, client.field_1724.method_24828(), client.field_1724.field_5976));
        }
    }

    private boolean attackReady(class_310 client) {
        String delayMode = hitDelay.getValue();
        if (delayMode.equals("Vanilla")) return client.field_1724.method_7261(0.5f) >= 1.0f;
        if (delayMode.equals("Custom")) {
            long delayNanos = (long) ((1000.0 - speed.getValue().doubleValue() * 50.0) * 1_000_000.0);
            return delayNanos <= 0 || System.nanoTime() - lastAttackTime >= delayNanos;
        }
        return true;
    }

    private class_1297 findTarget(class_310 client) {
        double maxRange = range.getValue().doubleValue();
        double maxWallRange = wallsRange.getValue().doubleValue();
        double rangeSquared = class_3532.method_33723(maxRange);
        double wallsRangeSquared = class_3532.method_33723(maxWallRange);
        double scanRadius = Math.max(maxRange, maxWallRange) + 1.0;
        class_243 eyePos = client.field_1724.method_33571();
        class_238 searchBox = client.field_1724.method_5829().method_1014(scanRadius);
        class_1297 best = null;

        for (class_1297 entity : client.field_1687.method_8333(client.field_1724, searchBox, candidate -> candidate.method_5805())) {
            if (entity.field_6012 < ticksExisted.getValue().intValue()) continue;
            if (entity instanceof class_1309 living && living.method_6032() <= 0.0f) continue;
            if (!client.field_1687.method_8621().method_11952(entity.method_24515())) continue;
            // Do not let the teammate check accidentally filter every remote player.
            // Keep the existing teammate filter for non-player entities only.
            if (!(entity instanceof class_1657) && client.field_1724.method_5722(entity)) continue;
            if (!isValidEntity(entity)) continue;

            double boxDistance = entity.method_5829().method_49271(eyePos);
            if (boxDistance >= rangeSquared) continue;
            boolean visible = canSee(client, entity);
            if (!visible && (raytrace.getValue() || boxDistance >= wallsRangeSquared)) continue;

            if (best == null || client.field_1724.method_5858(entity) < client.field_1724.method_5858(best)) best = entity;
        }

        return best;
    }

    private boolean isValidEntity(class_1297 entity) {
        if (players.getValue() && entity.method_5864() == class_1299.field_6097) return true;
        if (hostiles.getValue() && entity.method_5864().method_5891() == class_1311.field_6302) {
            if (!passives.getValue() && entity instanceof class_1560 enderman && !enderman.method_7028()) return false;
            if (!passives.getValue() && entity instanceof class_1590 piglin && !piglin.method_6510()) return false;
            return true;
        }
        if (animals.getValue() && (entity.method_5864().method_5891() == class_1311.field_6294 || entity.method_5864().method_5891() == class_1311.field_6300 || entity.method_5864().method_5891() == class_1311.field_24460 || entity.method_5864().method_5891() == class_1311.field_30092 || entity.method_5864().method_5891() == class_1311.field_34447)) return true;
        if (ambient.getValue() && entity.method_5864().method_5891() == class_1311.field_6303) return true;
        if (invisibles.getValue() && entity.method_5767()) return true;
        if (boats.getValue() && entity instanceof class_1690) return true;
        return shulkerBullets.getValue() && entity.method_5864() == class_1299.field_6100;
    }

    private boolean canSee(class_310 client, class_1297 entity) {
        class_243 start = client.field_1724.method_33571();
        class_243 end = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        return client.field_1687.method_17742(new class_3959(start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, client.field_1724)).method_17783() == class_239.class_240.field_1333;
    }

    @Override
    protected void onDisable() {
        target = null;
        attacking = false;
        silentRotationActive = false;
        lastAttackTime = 0L;
    }
}
