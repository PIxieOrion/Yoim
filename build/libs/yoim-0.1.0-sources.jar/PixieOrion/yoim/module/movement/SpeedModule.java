package PixieOrion.yoim.module.movement;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.Category;
import PixieOrion.yoim.module.Module;
import PixieOrion.yoim.settings.impl.NumberSetting;
import net.minecraft.class_1294;
import net.minecraft.class_2246;
import net.minecraft.class_243;
import net.minecraft.class_746;

public final class SpeedModule extends Module {
    public final NumberSetting strafeSpeed = setting(new NumberSetting("StrafeSpeed", "The strafe speed limit.", 0.465, 0.1, 0.576));
    private double distance;
    private double speed;
    private double forward;
    private int stage;
    private int ticks;

    public SpeedModule() {
        super("Speed", Category.MOVEMENT, "Makes movement faster.");
    }

    @Override
    protected void onEnable() {
        stage = 1;
        ticks = 0;
        distance = 0.0;
        speed = 0.0;
        forward = 0.0;
    }

    @Override
    protected void onDisable() {
        stage = 1;
        ticks = 0;
        distance = 0.0;
        speed = 0.0;
        forward = 0.0;
    }

    public class_243 modifyMovement(class_746 player, class_243 movement) {
        if (!isEnabled() || player == null || !isMoving(player)) return movement;
        if (player.field_6017 >= 5.0f || player.method_5715() || player.method_6101() || player.method_31549().field_7479 || player.method_6128()) return movement;
        if (player.method_52535()) return movement;
        if (player.method_73183().method_8320(player.method_24515()).method_26204() == class_2246.field_10343) return movement;

        distance = Math.sqrt(square(player.method_23317() - player.field_6014) + square(player.method_23321() - player.field_5969));
        speed = getPotionSpeed(0.2873) * (player.field_3913.method_3128().field_1342 <= 0.0f && forward > 0.0 ? 0.66 : 1.0);

        if (stage == 1 && isMoving(player) && player.field_5992) {
            double jump = getPotionJump(0.3999999463558197);
            player.method_18800(player.method_18798().field_1352, jump, player.method_18798().field_1350);
            movement = new class_243(movement.field_1352, jump, movement.field_1350);
            speed *= 2.149;
            stage = 2;
        } else if (stage == 2) {
            speed = distance - 0.66 * (distance - getPotionSpeed(0.2873));
            stage = 3;
        } else {
            if (!player.method_73183().method_20743(player, player.method_5829().method_989(0.0, player.method_18798().field_1351, 0.0)).isEmpty() || player.field_5992) {
                stage = 1;
            }
            speed = distance - distance / 159.0;
        }

        speed = Math.max(speed, getPotionSpeed(0.2873));

        double strafeCap = strafeSpeed.getValue().doubleValue();
        double ncp = getPotionSpeed(player.field_3913.method_3128().field_1342 < 1.0f ? strafeCap : 0.576);
        double bypass = getPotionSpeed(player.field_3913.method_3128().field_1342 < 1.0f ? Math.min(0.44, strafeCap) : 0.57);
        speed = Math.min(speed, ticks > 25 ? ncp : bypass);

        if (++ticks > 50) ticks = 0;

        class_243 velocity = forward(player, speed);
        forward = player.field_3913.method_3128().field_1342;
        return new class_243(velocity.field_1352, movement.field_1351, velocity.field_1350);
    }

    public boolean isMoving(class_746 player) {
        return player != null && (player.field_6212 != 0.0f || player.field_6250 != 0.0f);
    }

    private class_243 forward(class_746 player, double value) {
        float forwardInput = player.field_3913.method_3128().field_1342;
        float sideways = player.field_3913.method_3128().field_1343;
        float yaw = player.method_36454();

        if (forwardInput == 0.0f && sideways == 0.0f) return class_243.field_1353;
        if (forwardInput != 0.0f) {
            if (sideways >= 1.0f) {
                yaw += forwardInput > 0.0f ? -45.0f : 45.0f;
                sideways = 0.0f;
            } else if (sideways <= -1.0f) {
                yaw += forwardInput > 0.0f ? 45.0f : -45.0f;
                sideways = 0.0f;
            }
            if (forwardInput > 0.0f) forwardInput = 1.0f;
            else if (forwardInput < 0.0f) forwardInput = -1.0f;
        }

        double motionX = Math.cos(Math.toRadians(yaw + 90.0f));
        double motionZ = Math.sin(Math.toRadians(yaw + 90.0f));
        return new class_243(
                forwardInput * value * motionX + sideways * value * motionZ,
                0.0,
                forwardInput * value * motionZ - sideways * value * motionX
        );
    }

    private double getPotionSpeed(double value) {
        if (Yoim.mc().field_1724 == null) return value;
        if (Yoim.mc().field_1724.method_6059(class_1294.field_5904)) {
            value *= 1.0 + 0.2 * (Yoim.mc().field_1724.method_6112(class_1294.field_5904).method_5578() + 1);
        }
        if (Yoim.mc().field_1724.method_6059(class_1294.field_5909)) {
            value /= 1.0 + 0.2 * (Yoim.mc().field_1724.method_6112(class_1294.field_5909).method_5578() + 1);
        }
        return value;
    }

    private double getPotionJump(double value) {
        if (Yoim.mc().field_1724 != null && Yoim.mc().field_1724.method_6059(class_1294.field_5913)) {
            value += (Yoim.mc().field_1724.method_6112(class_1294.field_5913).method_5578() + 1) * 0.1;
        }
        return value;
    }

    private double square(double value) {
        return value * value;
    }
}
