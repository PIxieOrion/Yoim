package PixieOrion.yoim.module.render;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.Category;
import PixieOrion.yoim.module.Module;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public final class FullBrightModule extends Module {
    private double previousGamma = -1.0D;

    public FullBrightModule() {
        super("FullBright", Category.RENDER, "Removes client-side darkness while enabled.");
    }

    @Override
    protected void onEnable() {
        if (Yoim.mc().field_1724 != null) {
            previousGamma = Yoim.mc().field_1690.method_42473().method_41753();
        }
        apply();
    }

    @Override
    protected void onDisable() {
        if (previousGamma >= 0.0D) {
            Yoim.mc().field_1690.method_42473().method_41748(previousGamma);
            previousGamma = -1.0D;
        }
        if (Yoim.mc().field_1724 != null) {
            Yoim.mc().field_1724.method_6016(class_1294.field_5925);
        }
    }

    public void tick() {
        if (!isEnabled()) return;
        apply();
        if (Yoim.mc().field_1724 != null) {
            Yoim.mc().field_1724.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, false));
        }
    }

    private void apply() {
        Yoim.mc().field_1690.method_42473().method_41748(16.0D);
    }
}
