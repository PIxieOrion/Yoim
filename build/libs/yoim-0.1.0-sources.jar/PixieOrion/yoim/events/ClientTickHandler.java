package PixieOrion.yoim.events;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.gui.ClickGuiScreen;
import PixieOrion.yoim.module.client.ClickGuiModule;
import PixieOrion.yoim.module.combat.KillAuraModule;
import PixieOrion.yoim.module.render.FullBrightModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ClientTickHandler {
    private static boolean lastRightShift;
    private ClientTickHandler() {}

    public static void register() {
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            KillAuraModule aura = Yoim.MODULES.get(KillAuraModule.class);
            if (aura != null) aura.prepareTick();
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean guiWasOpen = client.field_1755 instanceof ClickGuiScreen;
            boolean pressed = class_3675.method_15987(client.method_22683(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (pressed && !lastRightShift && (client.field_1755 == null || client.field_1755 instanceof ClickGuiScreen)) toggleClickGui(client);
            lastRightShift = pressed;
            Yoim.MODULES.pollBinds(client.method_22683().method_4490(), !guiWasOpen && !(client.field_1755 instanceof ClickGuiScreen));
            KillAuraModule aura = Yoim.MODULES.get(KillAuraModule.class);
            if (aura != null) aura.attackTick();
            FullBrightModule fullBright = Yoim.MODULES.get(FullBrightModule.class);
            if (fullBright != null) fullBright.tick();
        });
    }

    private static void toggleClickGui(class_310 client) {
        ClickGuiModule gui = Yoim.MODULES.get(ClickGuiModule.class);
        if (client.field_1755 instanceof ClickGuiScreen) {
            gui.setEnabled(false);
            client.method_1507(null);
        } else {
            gui.setEnabled(true);
            client.method_1507(new ClickGuiScreen());
        }
    }
}
