package PixieOrion.yoim.packets;

import PixieOrion.yoim.Yoim;
import net.minecraft.class_2596;

public final class PacketUtils {
    private PacketUtils() {}

    public static void send(class_2596<?> packet) {
        if (Yoim.mc().method_1562() != null) Yoim.mc().method_1562().method_52787(packet);
    }
}
