package PixieOrion.yoim.core;

import PixieOrion.yoim.module.render.ShadersModule;
import java.util.Set;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_9922;

public final class YoimShaderRenderer {
    private static class_279 processor;
    private static String loadedPipeline;
    private static int loadedWidth = -1;
    private static int loadedHeight = -1;
    private static String failedPipeline;

    private YoimShaderRenderer() {}

    public static boolean render(class_276 entityMask, ShadersModule module) {
        class_310 client = class_310.method_1551();
        if (entityMask == null || entityMask.method_71639() == null || client.method_1522() == null) return false;

        String pipelineName = module.getPipelineName();
        int width = client.method_22683().method_4489();
        int height = client.method_22683().method_4506();
        if (processor == null || !pipelineName.equals(loadedPipeline) || width != loadedWidth || height != loadedHeight) {
            closeProcessor();
            if (pipelineName.equals(failedPipeline)) return false;
            try {
                processor = client.method_62887().method_62941(class_2960.method_60655("yoim", pipelineName), Set.of(class_279.field_53104));
                if (processor == null) {
                    failedPipeline = pipelineName;
                    System.err.println("[Yoim] Could not load custom post effect yoim:" + pipelineName + ". Using vanilla outline fallback.");
                    return false;
                }
                loadedPipeline = pipelineName;
                loadedWidth = width;
                loadedHeight = height;
                failedPipeline = null;
            } catch (Throwable error) {
                failedPipeline = pipelineName;
                System.err.println("[Yoim] Custom shader load failed for yoim:" + pipelineName + ": " + error.getMessage());
                return false;
            }
        }

        try {
            processor.method_1258(entityMask, class_9922.field_52741);
            client.method_1522().method_68445(entityMask.method_71639());
            return true;
        } catch (Throwable error) {
            closeProcessor();
            failedPipeline = pipelineName;
            System.err.println("[Yoim] Custom post effect failed at render time: " + error.getMessage());
            return false;
        }
    }

    private static void closeProcessor() {
        if (processor != null) {
            try { processor.close(); } catch (Throwable ignored) {}
        }
        processor = null;
        loadedPipeline = null;
        loadedWidth = -1;
        loadedHeight = -1;
    }
}
