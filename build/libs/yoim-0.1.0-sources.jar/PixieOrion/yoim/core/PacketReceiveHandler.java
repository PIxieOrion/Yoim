package PixieOrion.yoim.core;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.mixin.accessor.EntityVelocityUpdateS2CPacketAccessor;
import PixieOrion.yoim.mixin.accessor.Vec3dAccessor;
import PixieOrion.yoim.module.movement.VelocityModule;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2743;

public final class PacketReceiveHandler {
    private PacketReceiveHandler() {
    }

    public static boolean handle(class_2596<?> packet) {
        if (packet instanceof class_2743 velocityPacket) {
            return handleVelocity(velocityPacket);
        }
        if (packet instanceof class_2664 explosionPacket) {
            return handleExplosion(explosionPacket);
        }
        return false;
    }

    private static boolean handleVelocity(class_2743 packet) {
        VelocityModule module = Yoim.MODULES.get(VelocityModule.class);
        if (module == null || !module.isEnabled() || Yoim.mc().field_1724 == null) return false;
        if (packet.method_11818() != Yoim.mc().field_1724.method_5628()) return false;

        String mode = module.mode.getValue();
        if (mode.equals("Cancel")) return true;

        double horizontal = module.horizontal.getValue().doubleValue() / 100.0D;
        double vertical = module.vertical.getValue().doubleValue() / 100.0D;
        class_243 current = Yoim.mc().field_1724.method_18798();
        class_243 incoming = packet.method_73085();
        class_243 modified = new class_243(
                (incoming.field_1352 - current.field_1352) * horizontal + current.field_1352,
                (incoming.field_1351 - current.field_1351) * vertical + current.field_1351,
                (incoming.field_1350 - current.field_1350) * horizontal + current.field_1350
        );
        ((EntityVelocityUpdateS2CPacketAccessor) (Object) packet).setVelocity(modified);
        return false;
    }

    private static boolean handleExplosion(class_2664 packet) {
        VelocityModule module = Yoim.MODULES.get(VelocityModule.class);
        if (module == null || !module.isEnabled() || !module.explosions.getValue()) return false;

        String mode = module.mode.getValue();
        if (packet.comp_2884().isEmpty()) return false;

        class_243 knockback = packet.comp_2884().get();
        Vec3dAccessor accessor = (Vec3dAccessor) (Object) knockback;

        if (mode.equals("Cancel")) {
            // Keep the original explosion packet intact for Minecraft's normal
            // sound, particles, and other effects; only remove its player knockback.
            accessor.setX(0.0D);
            accessor.setY(0.0D);
            accessor.setZ(0.0D);
            return false;
        }

        if (mode.equals("Normal")) {
            double horizontal = module.horizontal.getValue().doubleValue() / 100.0D;
            double vertical = module.vertical.getValue().doubleValue() / 100.0D;
            accessor.setX(knockback.field_1352 * horizontal);
            accessor.setY(knockback.field_1351 * vertical);
            accessor.setZ(knockback.field_1350 * horizontal);
        }
        return false;
    }
}
