package PixieOrion.yoim.core;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.mixin.accessor.EntityVelocityUpdateS2CPacketAccessor;
import PixieOrion.yoim.mixin.accessor.Vec3dAccessor;
import PixieOrion.yoim.module.movement.VelocityModule;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_3419;

public final class PacketReceiveHandler {
    private PacketReceiveHandler() {
    }

    public static boolean handle(class_2596<?> packet) {
        if (packet instanceof class_2743 velocityPacket) {
            return handleVelocity(velocityPacket);
        }
        if (packet instanceof class_2664 explosionPacket) {
            return handleExplosion(explosionPacket);
        }
        return false;
    }

    private static boolean handleVelocity(class_2743 packet) {
        VelocityModule module = Yoim.MODULES.get(VelocityModule.class);
        if (module == null || !module.isEnabled() || Yoim.mc().field_1724 == null) return false;
        if (packet.method_11818() != Yoim.mc().field_1724.method_5628()) return false;

        String mode = module.mode.getValue();
        if (mode.equals("Cancel")) return true;

        double horizontal = module.horizontal.getValue().doubleValue() / 100.0D;
        double vertical = module.vertical.getValue().doubleValue() / 100.0D;
        class_243 current = Yoim.mc().field_1724.method_18798();
        class_243 incoming = packet.method_73085();
        class_243 modified = new class_243(
                (incoming.field_1352 - current.field_1352) * horizontal + current.field_1352,
                (incoming.field_1351 - current.field_1351) * vertical + current.field_1351,
                (incoming.field_1350 - current.field_1350) * horizontal + current.field_1350
        );
        ((EntityVelocityUpdateS2CPacketAccessor) (Object) packet).setVelocity(modified);
        return false;
    }

    private static boolean handleExplosion(class_2664 packet) {
        VelocityModule module = Yoim.MODULES.get(VelocityModule.class);
        if (module == null || !module.isEnabled() || !module.explosions.getValue()) return false;

        String mode = module.mode.getValue();
        if (mode.equals("Normal")) {
            if (packet.comp_2884().isPresent()) {
                class_243 knockback = packet.comp_2884().get();
                double horizontal = module.horizontal.getValue().doubleValue() / 100.0D;
                double vertical = module.vertical.getValue().doubleValue() / 100.0D;
                Vec3dAccessor accessor = (Vec3dAccessor) (Object) knockback;
                accessor.setX(knockback.field_1352 * horizontal);
                accessor.setY(knockback.field_1351 * vertical);
                accessor.setZ(knockback.field_1350 * horizontal);
            }
            return false;
        }

        if (!mode.equals("Cancel")) return false;

        Yoim.mc().method_40000(() -> {
            if (Yoim.mc().field_1687 == null) return;
            class_243 center = packet.comp_2883();
            Yoim.mc().field_1687.method_47967(
                    null,
                    center.method_10216(),
                    center.method_10214(),
                    center.method_10215(),
                    packet.comp_2886().comp_349(),
                    class_3419.field_15245,
                    4.0F,
                    (1.0F + (Yoim.mc().field_1687.field_9229.method_43057() - Yoim.mc().field_1687.field_9229.method_43057()) * 0.2F) * 0.7F,
                    0L
            );
            Yoim.mc().field_1687.method_8466(
                    packet.comp_2885(),
                    true,
                    false,
                    center.method_10216(),
                    center.method_10214(),
                    center.method_10215(),
                    0.0D,
                    0.0D,
                    0.0D
            );
        });
        return true;
    }
}
