package PixieOrion.yoim.core;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.mixin.accessor.EntityRenderManagerAccessor;
import PixieOrion.yoim.mixin.accessor.ItemRenderStateAccessor;
import PixieOrion.yoim.mixin.accessor.LayerRenderStateAccessor;
import PixieOrion.yoim.module.render.NameTagsModule;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_918;

public final class NameTagsRenderer {
    private static final int ICON_SIZE = 16;
    private static final int SLOT_SPACING = 18;
    private static final int SLOT_COUNT = 6;

    private NameTagsRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(NameTagsRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || context.matrices() == null || context.consumers() == null) return;
        NameTagsModule module = Yoim.MODULES.get(NameTagsModule.class);
        if (module == null || !module.isEnabled()) return;

        class_4184 camera = client.field_1773.method_19418();
        class_243 cameraPos = camera.method_71156();
        class_4587 matrices = context.matrices();
        class_4597 consumers = context.consumers();
        class_327 font = client.field_1772;
        float scaleSetting = module.scale.getValue().floatValue();
        class_10442 itemModels = ((EntityRenderManagerAccessor) client.method_1561()).yoim$getItemModelManager();

        for (class_1657 player : client.field_1687.method_18456()) {
            if (player == client.field_1724 || player.method_31481() || player.method_5767()) continue;

            double x = player.method_23317();
            double y = player.method_23318() + (player.method_5715() ? 1.9 : 2.1);
            double z = player.method_23321();
            class_243 delta = new class_243(x - cameraPos.field_1352, y - cameraPos.field_1351, z - cameraPos.field_1350);
            double distanceSq = cameraPos.method_1028(x, y, z);
            float distance = (float) Math.sqrt(distanceSq);
            float scaling = 0.0018f + (scaleSetting / 10000.0f) * distance;
            if (distance <= 8.0f) scaling = 0.0245f;

            class_2561 label = class_2561.method_43470(player.method_5477().getString()).method_27692(player.method_5715() ? class_124.field_1065 : class_124.field_1068);
            if (module.ping.getValue() && client.method_1562() != null) {
                var entry = client.method_1562().method_2871(player.method_5667());
                if (entry != null) label = label.method_27661().method_10852(class_2561.method_43470(" " + entry.method_2959() + "ms").method_27692(class_124.field_1080));
            }
            if (module.health.getValue()) {
                float hp = player.method_6032() + player.method_6067();
                class_124 hpColor = hp > 15.0f ? class_124.field_1060 : hp > 7.0f ? class_124.field_1054 : class_124.field_1061;
                label = label.method_27661().method_10852(class_2561.method_43470(" " + String.format(java.util.Locale.ROOT, "%.1f", hp)).method_27692(hpColor));
            }

            int width = font.method_27525(label);
            matrices.method_22903();
            matrices.method_22904(delta.field_1352, delta.field_1351, delta.field_1350);
            matrices.method_22907(camera.method_23767());
            matrices.method_22905(scaling, -scaling, scaling);

            if (module.items.getValue()) {
                class_1799[] stacks = getStacks(player);
                int rowWidth = SLOT_COUNT * SLOT_SPACING;
                float startX = -rowWidth / 2.0f + 1.0f;
                float itemY = -font.field_2000 - ICON_SIZE - 3.0f;
                for (int i = 0; i < stacks.length; i++) {
                    class_1799 stack = stacks[i];
                    if (stack.method_7960()) continue;
                    float slotX = startX + i * SLOT_SPACING;
                    renderItemIcon(client, itemModels, stack, player, matrices, consumers,
                            slotX + 1.0f, itemY, player.method_5628() + i);
                    if (module.durability.getValue() && stack.method_7963()) {
                        int remaining = Math.round((stack.method_7936() - stack.method_7919()) * 100.0f / stack.method_7936());
                        class_124 durabilityColor = remaining > 60 ? class_124.field_1060 : remaining > 25 ? class_124.field_1054 : class_124.field_1061;
                        class_2561 durabilityText = class_2561.method_43470(remaining + "%").method_27692(durabilityColor);
                        matrices.method_22903();
                        matrices.method_46416(slotX + (SLOT_SPACING - font.method_27525(durabilityText) * 0.5f) / 2.0f,
                                itemY - font.field_2000 * 0.55f, 0.0f);
                        matrices.method_22905(0.5f, -0.5f, 0.5f);
                        font.method_27522(durabilityText, 0.0f, 0.0f, 0xFFFFFFFF, true,
                                matrices.method_23760().method_23761(), consumers, class_327.class_6415.field_33994,
                                0x80000000, class_765.field_32767);
                        matrices.method_22909();
                    }
                }
            }

            font.method_27522(label, -width / 2.0f, -font.field_2000, 0xFFFFFFFF, true,
                    matrices.method_23760().method_23761(), consumers, class_327.class_6415.field_33994,
                    0x80000000, class_765.field_32767);
            matrices.method_22909();
        }
    }

    private static class_1799[] getStacks(class_1657 player) {
        return new class_1799[] {
                player.method_6047(),
                player.method_6118(class_1304.field_6169),
                player.method_6118(class_1304.field_6174),
                player.method_6118(class_1304.field_6172),
                player.method_6118(class_1304.field_6166),
                player.method_6079()
        };
    }

    private static void renderItemIcon(class_310 client, class_10442 itemModels, class_1799 stack,
                                       class_1657 owner, class_4587 matrices, class_4597 consumers,
                                       float x, float y, int seed) {
        class_10444 state = new class_10444();
        itemModels.method_65597(state, stack, class_811.field_4317, owner);
        if (state.method_65606()) return;
        ItemRenderStateAccessor stateAccessor = (ItemRenderStateAccessor) state;

        matrices.method_22903();
        matrices.method_46416(x + ICON_SIZE / 2.0f, y + ICON_SIZE / 2.0f, 0.0f);
        matrices.method_22905(ICON_SIZE, -ICON_SIZE, -0.001f);
        for (int i = 0; i < stateAccessor.yoim$getLayerCount(); i++) {
            var layer = stateAccessor.yoim$getLayers()[i];
            LayerRenderStateAccessor layerAccessor = (LayerRenderStateAccessor) layer;
            if (layerAccessor.yoim$getSpecialModelType() != null || layer.method_67997().isEmpty()) continue;
            matrices.method_22903();
            layerAccessor.yoim$getTransform().method_23075(false, matrices.method_23760());
            class_918.method_62476(class_811.field_4317, matrices, consumers,
                    class_765.field_32767, class_4608.field_21444,
                    layerAccessor.yoim$getTints(), layer.method_67997(), layerAccessor.yoim$getRenderLayer(), layerAccessor.yoim$getGlint());
            matrices.method_22909();
        }
        matrices.method_22909();
    }
}
