package PixieOrion.yoim.mixin;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.render.ShadersModule;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297, S extends class_10017> {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void yoim$shaderMask(T entity, S state, float tickProgress, CallbackInfo ci) {
        ShadersModule module = Yoim.MODULES.get(ShadersModule.class);
        if (module != null && module.isEnabled() && module.isValidEntity(entity)) {
            state.field_61821 = module.getOutlineColor();
        }
    }
}
