package PixieOrion.yoim.mixin;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.movement.NoSlowModule;
import PixieOrion.yoim.module.combat.KillAuraModule;
import PixieOrion.yoim.module.movement.SpeedModule;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_746.class)
public abstract class ClientPlayerEntityMovementMixin {
    @Unique private float yoim$cameraYawBeforePacket;
    @Unique private float yoim$cameraPitchBeforePacket;
    @Unique private boolean yoim$temporaryRotationApplied;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void yoim$applyRotationToMovementPacket(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        KillAuraModule module = Yoim.MODULES.get(KillAuraModule.class);
        yoim$temporaryRotationApplied = module != null && module.hasVisualRotation();
        if (!yoim$temporaryRotationApplied) return;
        yoim$cameraYawBeforePacket = player.method_36454();
        yoim$cameraPitchBeforePacket = player.method_36455();
        player.method_36456(module.getSilentYaw());
        player.method_36457(module.getSilentPitch());
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void yoim$restoreCameraRotation(CallbackInfo ci) {
        if (!yoim$temporaryRotationApplied) return;
        class_746 player = (class_746) (Object) this;
        player.method_36456(yoim$cameraYawBeforePacket);
        player.method_36457(yoim$cameraPitchBeforePacket);
        yoim$temporaryRotationApplied = false;
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true)
    private class_243 yoim$strafe(class_243 movement) {
        class_746 player = (class_746) (Object) this;
        SpeedModule module = Yoim.MODULES.get(SpeedModule.class);
        if (module != null && module.isEnabled()) return module.modifyMovement(player, movement);
        return movement;
    }

    @Inject(method = "getActiveItemSpeedMultiplier", at = @At("RETURN"), cancellable = true)
    private void yoim$noSlowSpeed(CallbackInfoReturnable<Float> cir) {
        NoSlowModule module = Yoim.MODULES.get(NoSlowModule.class);
        if (module != null && module.isEnabled() && module.items.getValue() && !module.shouldSlow()) {
            cir.setReturnValue(1.0f);
        }
    }

    @Inject(method = "isBlockedFromSprinting", at = @At("RETURN"), cancellable = true)
    private void yoim$noSlowSprint(CallbackInfoReturnable<Boolean> cir) {
        NoSlowModule module = Yoim.MODULES.get(NoSlowModule.class);
        if (module != null && module.isEnabled() && module.items.getValue() && !module.shouldSlow()) {
            cir.setReturnValue(false);
        }
    }
}
