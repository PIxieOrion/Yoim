package PixieOrion.yoim.mixin;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.movement.NoSlowModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

@Mixin(class_1297.class)
public abstract class NoSlowEntityMixin {
    @ModifyExpressionValue(method = "getVelocityMultiplier", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;getBlock()Lnet/minecraft/block/Block;"))
    private class_2248 yoim$blockSlow(class_2248 original) {
        NoSlowModule module = Yoim.MODULES.get(NoSlowModule.class);
        if (module != null && module.isEnabled()) {
            if ((original == class_2246.field_10114 && module.soulSand.getValue()) || (original == class_2246.field_21211 && module.honeyBlocks.getValue())) return class_2246.field_10340;
        }
        return original;
    }
}
