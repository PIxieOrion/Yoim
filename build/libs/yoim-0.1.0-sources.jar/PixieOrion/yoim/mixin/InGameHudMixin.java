package PixieOrion.yoim.mixin;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.render.NoRenderModule;
import PixieOrion.yoim.module.Module;
import PixieOrion.yoim.module.client.ArrayListModule;
import PixieOrion.yoim.module.client.ColorsModule;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void yoim$arrayList(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        ArrayListModule arrayList = Yoim.MODULES.get(ArrayListModule.class);
        if (arrayList == null || !arrayList.isEnabled() || Yoim.mc().field_1724 == null || Yoim.mc().field_1690.field_1842) return;
        if (Yoim.mc().field_1755 instanceof PixieOrion.yoim.gui.ClickGuiScreen) return;

        class_327 renderer = Yoim.mc().field_1772;
        List<Module> visible = new ArrayList<>();
        for (Module module : Yoim.MODULES.all()) {
            if (module != arrayList && module.isEnabled() && module.drawn.getValue()) visible.add(module);
        }
        visible.sort(Comparator.comparingInt((Module module) -> renderer.method_1727(module.getName())).reversed());

        int margin = (int) arrayList.offset.getValue();
        int y = margin;
        int screenWidth = context.method_51421();
        int accentColor = ColorsModule.getGlobalColor().getRGB();
        for (Module module : visible) {
            String name = module.getName();
            int width = renderer.method_1727(name);
            int x = screenWidth - margin - width - 4;
            if (arrayList.background.getValue()) context.method_25294(x - 3, y - 1, screenWidth - margin, y + 10, 0x90000000);
            if (arrayList.accent.getValue()) context.method_25294(screenWidth - margin - 2, y - 1, screenWidth - margin, y + 10, accentColor);
            context.method_27535(renderer, class_2561.method_43470(name), x, y, 0xFFFFFFFF);
            y += 11;
        }
    }
    @Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true)
    private void yoim$portal(class_332 context, float nauseaStrength, CallbackInfo ci) {
        NoRenderModule module = Yoim.MODULES.get(NoRenderModule.class);
        if (module != null && module.isEnabled() && module.portalOverlay.getValue()) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
    private void yoim$vignette(class_332 context, class_1297 entity, CallbackInfo ci) {
        NoRenderModule module = Yoim.MODULES.get(NoRenderModule.class);
        if (module != null && module.isEnabled() && module.vignette.getValue()) ci.cancel();
    }

    @Inject(method = "renderMiscOverlays", at = @At("HEAD"), cancellable = true)
    private void yoim$misc(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        NoRenderModule module = Yoim.MODULES.get(NoRenderModule.class);
        if (module != null && module.isEnabled() && (module.pumpkinOverlay.getValue() || module.snowOverlay.getValue())) ci.cancel();
    }
}
