package PixieOrion.yoim.mixin;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.movement.NoSlowModule;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public abstract class NoSlowBlockMixin {
    @Inject(method = "getSlipperiness", at = @At("HEAD"), cancellable = true)
    private void yoim$slime(CallbackInfoReturnable<Float> cir) {
        if ((Object) this == class_2246.field_10030) {
            NoSlowModule module = Yoim.MODULES.get(NoSlowModule.class);
            if (module != null && module.isEnabled() && module.slimeBlocks.getValue()) cir.setReturnValue(0.6f);
        }
    }
}
