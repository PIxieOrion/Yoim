package PixieOrion.yoim.mixin.accessor;

import net.minecraft.class_10442;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_898.class)
public interface EntityRenderManagerAccessor {
    @Accessor("itemModelManager")
    class_10442 yoim$getItemModelManager();
}
