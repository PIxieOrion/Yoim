package PixieOrion.yoim.mixin.accessor;

import net.minecraft.class_276;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_761.class)
public interface WorldRendererAccessor {
    @Accessor("entityOutlineFramebuffer")
    class_276 yoim$getEntityOutlineFramebuffer();
}
