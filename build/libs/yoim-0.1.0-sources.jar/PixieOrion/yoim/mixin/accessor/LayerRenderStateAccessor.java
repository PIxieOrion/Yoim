package PixieOrion.yoim.mixin.accessor;

import net.minecraft.class_10444;
import net.minecraft.class_10444.class_10445;
import net.minecraft.class_10515;
import net.minecraft.class_1921;
import net.minecraft.class_804;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10444.class_10446.class)
public interface LayerRenderStateAccessor {
    @Accessor("tints") int[] yoim$getTints();
    @Accessor("renderLayer") class_1921 yoim$getRenderLayer();
    @Accessor("glint") class_10445 yoim$getGlint();
    @Accessor("transform") class_804 yoim$getTransform();
    @Accessor("specialModelType") class_10515<?> yoim$getSpecialModelType();
}
