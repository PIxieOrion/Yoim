package PixieOrion.yoim.mixin.accessor;

import net.minecraft.class_243;
import net.minecraft.class_2743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2743.class)
public interface EntityVelocityUpdateS2CPacketAccessor {
    @Accessor("velocity")
    class_243 getVelocity();

    @Accessor("velocity")
    @Mutable
    void setVelocity(class_243 velocity);
}
