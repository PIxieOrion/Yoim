package PixieOrion.yoim.mixin.accessor;

import net.minecraft.class_10444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10444.class)
public interface ItemRenderStateAccessor {
    @Accessor("layerCount")
    int yoim$getLayerCount();

    @Accessor("layers")
    class_10444.class_10446[] yoim$getLayers();
}
