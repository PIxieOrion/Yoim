package PixieOrion.yoim.mixin;

import PixieOrion.yoim.Yoim;
import PixieOrion.yoim.module.combat.KillAuraModule;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, S extends class_10042> {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void yoim$renderSilentRotation(T entity, S state, float tickProgress, CallbackInfo ci) {
        if (entity != Yoim.mc().field_1724) return;
        KillAuraModule aura = Yoim.MODULES.get(KillAuraModule.class);
        if (aura == null || !aura.hasVisualRotation()) return;
        state.field_53446 = aura.getSilentYaw();
        state.field_53447 = 0.0f;
        state.field_53448 = aura.getSilentPitch();
    }
}
