package PixieOrion.yoim.mixin;

import io.netty.channel.ChannelHandlerContext;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_8042;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import PixieOrion.yoim.core.PacketReceiveHandler;

@Mixin(class_2535.class)
public abstract class ClientConnectionMixin {
    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void yoim$channelRead0(ChannelHandlerContext context, class_2596<?> packet, CallbackInfo ci) {
        boolean cancelled = PacketReceiveHandler.handle(packet);
        if (packet instanceof class_8042 bundle) {
            for (class_2596<?> subPacket : bundle.method_48324()) {
                PacketReceiveHandler.handle(subPacket);
            }
        }
        if (cancelled) ci.cancel();
    }
}
