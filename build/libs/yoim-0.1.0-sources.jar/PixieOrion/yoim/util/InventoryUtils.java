package PixieOrion.yoim.util;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class InventoryUtils {
    private InventoryUtils() {}

    public static boolean isSword(class_1792 item) {
        return item == class_1802.field_8091 || item == class_1802.field_8528 || item == class_1802.field_8371 || item == class_1802.field_8845 || item == class_1802.field_8802 || item == class_1802.field_22022;
    }

    public static int findBestSword(class_310 client) {
        class_1792[] swords = {class_1802.field_8091, class_1802.field_8528, class_1802.field_8371, class_1802.field_8845, class_1802.field_8802, class_1802.field_22022};
        for (int i = swords.length - 1; i >= 0; i--) {
            for (int slot = 8; slot >= 0; slot--) {
                if (client.field_1724.method_31548().method_5438(slot).method_31574(swords[i])) return slot;
            }
        }
        return -1;
    }
}
